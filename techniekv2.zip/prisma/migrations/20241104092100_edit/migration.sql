/*
  Warnings:

  - You are about to drop the column `kanalen` on the `lightinginventory` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `lightinginventory` DROP COLUMN `kanalen`;
